# FA3 descale reproduction evidence

This bundle contains measured release/v0.5.23 results, not a GPU test of PR head or current main. The tested patch is `public_fix.diff`; the follow-up candidate is a separate artifact.

Baseline: `297e54fd105e974cdf401e5b4d20253a22c16f90`.
Tested patch SHA-256: `2ba3b2d6737b108f80c2c129c740e9f6fc1b92db204221ab381e7f3d88f7b928`.

`predictions/<run>.jsonl` contains normalized per-sample results. Original evaluator output and metrics are under `predictions/<run>/sgl_eval_gsm8k_*/`. `metrics.json` records all six runs. No original scores or generated answers have been edited.

To verify aggregate counts: `python3 scripts/analyze.py`. This regenerates metrics.json from the original evaluator outputs; preserve the distributed summary first if desired.

Reproduction commands and experiment differences are in `configs/experiments.md`. Shell helpers have been parameterized for redistribution; set `MODEL_DIR`, `RESULT_DIR`, and optionally `SGL_EVAL_BIN` (sgl-eval 0.1.3). They are reproduction templates, not evidence of additional GPU runs. Exact launch records replace original model-directory paths with `${MODEL_DIR}`.

Example (on an appropriately configured GPU host):
```sh
export MODEL_DIR=/path/to/models
export RESULT_DIR=/path/to/new-results
export SGL_EVAL_BIN=/path/to/eval-venv/bin/sgl-eval
bash scripts/launch.sh patched spec
# In another terminal after the server is ready:
bash scripts/eval_gsm8k.sh patched 256
```

Model target: Qwen/Qwen3-Next-80B-A3B-Instruct-FP8, revision c5f5f263bdd5cc134092897864e8905d8fe7b928.
Draft: lmsys/SGLang-EAGLE3-Qwen3-Next-80B-A3B-Instruct-FP8-SpecForge-Meituan.
GSM8K data SHA-256: 67e9046d913470477dfb321814d4e3240240a397cfc19c6c610af02dd2cb6456.

Full package/CUDA integration and uncovered attention branches are not claimed as verified. Read `pr_accuracy_comment.md` for limitations and truncated-output counts.
