# Experiment configurations

Exact server command lines are in `<run>.server_cmd.txt`; the environment variables
(`SGLANG_*`, `NCCL_*`, `CUDA_VISIBLE*`) visible to each server are in `<run>.env.txt`.
Source provenance (HEAD, tracked-file status, imported file path, md5) is in
`../logs/<run>_source.txt`.

BASE = 297e54fd105e974cdf401e5b4d20253a22c16f90 (public release/v0.5.23 baseline)
FIX  = 73c772de7e0fc2a3e8c02c71b6a3c147620d044d (local tested commit; BASE + public_fix.diff, not a GPU run of PR head)

## Common server flags (all runs)

```
--model-path Qwen3-Next-80B-A3B-Instruct-FP8
--attention-backend fa3 --kv-cache-dtype fp8_e4m3
--tp 8 --dp 8 --enable-dp-attention --ep-size 8
--max-running-requests 512 --cuda-graph-max-bs-decode 8
--mem-fraction-static 0.8 --host 127.0.0.1 --port 30123
--nccl-port 26123 --dist-init-addr 127.0.0.1:26300
```

Speculative flags (`spec` runs):

```
--speculative-algorithm EAGLE3
--speculative-draft-model-path SGLang-EAGLE3-Qwen3-Next-80B-A3B-Instruct-FP8-SpecForge-Meituan
--speculative-draft-model-quantization fp8
--speculative-num-steps 3 --speculative-eagle-topk 1 --speculative-num-draft-tokens 4
```

## Runs

| run | source | mode | purpose |
|---|---|---|---|
| A_base_spec | BASE | spec | A: reproduce crash before the fix |
| Bdiag_fix_spec | FIX + scripts/diag_coverage.patch | spec | B: path-coverage evidence (temporary diagnostics) |
| BD_fix_spec | FIX (clean) | spec | B: load sweep, D: GSM8K on problem config |
| BD_fix_spec_repeat | FIX (clean) | spec | D repeated, run-to-run noise |
| C_base_nospec | BASE | nospec | C: reference accuracy (no spec) |
| E_fix_nospec | FIX | nospec | E: direct base-vs-fix pair without spec |
| E2_base_spec_nodp | BASE | spec, no DP attn | E: direct base-vs-fix pair with spec |
| E2_fix_spec_nodp | FIX | spec, no DP attn | E: direct base-vs-fix pair with spec |

## Differences between C (reference) and D (problem config)

| item | C_base_nospec | BD_fix_spec | why |
|---|---|---|---|
| source | BASE | FIX | C must run on code that does not crash; BASE crashes with spec+DP |
| speculative decoding | off | EAGLE3 (steps 3, topk 1, draft tokens 4) | spec is the trigger; with it BASE crashes, so the reference turns it off |
| draft model quantization | n/a | fp8 | needed so the draft's RadixAttention gets k_scale and goes through the FP8 descale code |
| everything else | identical | identical | |

E_fix_nospec vs C_base_nospec and E2_* pairs differ only in source SHA.
E2 removes `--dp 8 --enable-dp-attention` (attention TP 8); the MoE stays EP 8.

## Deviations from the Qwen3-Next cookbook page

`docs/cookbook/autoregressive/Qwen/Qwen3-Next.mdx` recommends `--tp 8` (or
NEXTN MTP with `--tp 4`) and the default attention backend. These runs add
FA3, FP8 KV cache, DP attention, EP 8 and an external EAGLE3 draft because those
are the conditions that reach the bug; this is a regression configuration, not a
deployment recommendation. `--ep-size 8` is required: without it, server start
fails with "The output_size of gate's and up's weight = 64 is not divisible by
weight quantization block_n = 128" (MoE intermediate 512 / TP 8 = 64).

## Load-test workloads (sglang.bench_serving, random-ids dataset, ignore_eos default)

| tag | prompts | concurrency | input len | output len | range ratio | seed |
|---|---|---|---|---|---|---|
| repro | 400 | 200 | 1024 | 1024 | 0.05 | 1 |
| short_c256 | 800 | 256 | 128 | 512 | 0.1 | 3 |
| long_c32 | 96 | 32 | 8000 | 1024 | 0.05 | 4 |
| mixed_c128 | 400 | 128 | 4000 | 1024 | 0.01 | 5 |
| mixed_c64 (diag run only) | 300 | 64 | 6000 | 1024 | 0.02 | 2 |

## Accuracy eval (identical for every run)

sgl-eval 0.1.3 (version pinned in python/pyproject.toml `test` extra), host venv
separate from the server env:

```
sgl-eval run gsm8k --base-url http://127.0.0.1:30123/v1 \
  --temperature 0.0 --top-p 1.0 --seed 0 --max-tokens 2048 --num-threads 256
```

GSM8K test split, all 1319 problems, sgl-eval's vendored NeMo-Skills gsm8k
prompt, 0-shot chat completions, thinking off (benchmark default; the model is an
Instruct model). Dataset file sha256 67e9046d913470477dfb321814d4e3240240a397cfc19c6c610af02dd2cb6456.
