#!/bin/bash
# Host side (sgl-eval 0.1.3 in its own venv). usage: eval_gsm8k.sh <run_name> <num_threads>
RUN=$1; T=$2; O=${RESULT_DIR:?Set RESULT_DIR}
mkdir -p "$O/predictions/$RUN" "$O/logs"
"${SGL_EVAL_BIN:-sgl-eval}" run gsm8k --base-url http://127.0.0.1:30123/v1 \
  --temperature 0.0 --top-p 1.0 --seed 0 --max-tokens 2048 --num-threads $T \
  --out-dir "$O/predictions/$RUN" > "$O/logs/${RUN}.gsm8k.log" 2>&1
status=$?
echo "eval exit code: $status" >> "$O/logs/${RUN}.gsm8k.log"
exit "$status"
