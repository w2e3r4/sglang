#!/bin/bash
# Run INSIDE the container. usage: bench.sh <run_name> <tag> <num_prompts> <concurrency> <in_len> <out_len> <range_ratio> [seed]
RUN=$1; TAG=$2; N=$3; C=$4; IN=$5; OUTL=$6; RR=$7; SEED=${8:-1}
OUT=${RESULT_DIR:?Set RESULT_DIR}
M=${MODEL_DIR:?Set MODEL_DIR}
mkdir -p "$OUT/logs"
python3 -m sglang.bench_serving --backend sglang --host 127.0.0.1 --port 30123 \
  --model "$M/Qwen3-Next-80B-A3B-Instruct-FP8" \
  --dataset-name random-ids --random-input-len $IN --random-output-len $OUTL --random-range-ratio $RR \
  --num-prompts $N --max-concurrency $C --seed $SEED \
  --output-file "$OUT/logs/${RUN}.bench_${TAG}.jsonl" > "$OUT/logs/${RUN}.bench_${TAG}.log" 2>&1
status=$?
echo "bench exit code: $status" >> "$OUT/logs/${RUN}.bench_${TAG}.log"
exit "$status"
