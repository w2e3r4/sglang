#!/bin/bash
# Run INSIDE the container. usage: launch.sh <run_name> <spec|nospec|spec_nodp> [extra server args...]
# spec_nodp = same as spec but without --dp 8 --enable-dp-attention (attention TP=8).
RUN=$1; MODE=$2; shift 2
M=${MODEL_DIR:?Set MODEL_DIR to the directory containing both models}
OUT=${RESULT_DIR:?Set RESULT_DIR to an output directory}
mkdir -p "$OUT/configs" "$OUT/logs"
COMMON=(--model-path "$M/Qwen3-Next-80B-A3B-Instruct-FP8"
  --attention-backend fa3 --kv-cache-dtype fp8_e4m3
  --tp 8 --dp 8 --enable-dp-attention --ep-size 8
  --max-running-requests 512 --cuda-graph-max-bs-decode 8
  --mem-fraction-static 0.8
  --host 127.0.0.1 --port 30123 --nccl-port 26123 --dist-init-addr 127.0.0.1:26300)
SPEC=(--speculative-algorithm EAGLE3
  --speculative-draft-model-path "$M/SGLang-EAGLE3-Qwen3-Next-80B-A3B-Instruct-FP8-SpecForge-Meituan"
  --speculative-draft-model-quantization fp8
  --speculative-num-steps 3 --speculative-eagle-topk 1 --speculative-num-draft-tokens 4)
ARGS=("${COMMON[@]}"); [ "$MODE" != nospec ] && ARGS+=("${SPEC[@]}")
if [ "$MODE" = spec_nodp ]; then
  NEW=(); skip=0
  for a in "${ARGS[@]}"; do
    if [ $skip = 1 ]; then skip=0; continue; fi
    case "$a" in --dp) skip=1;; --enable-dp-attention) ;; *) NEW+=("$a");; esac
  done; ARGS=("${NEW[@]}")
fi
ARGS+=("$@")
printf '%s\n' "python3 -m sglang.launch_server ${ARGS[*]}" > "$OUT/configs/${RUN}.server_cmd.txt"
env | grep -E '^(SGLANG|NCCL|CUDA_VISIBLE)' | sort > "$OUT/configs/${RUN}.env.txt"
export NCCL_DEBUG=WARN
python3 -m sglang.launch_server "${ARGS[@]}" > "$OUT/logs/${RUN}.server.log" 2>&1
status=$?
echo "server exit code: $status" >> "$OUT/logs/${RUN}.server.log"
exit "$status"
