# Aggregate sgl-eval runs into metrics.json, normalized predictions, and per-sample flip lists.
import json, glob, os, sys
O = os.environ.get("RESULT_DIR", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BASE = "297e54fd105e974cdf401e5b4d20253a22c16f90"
FIX = "73c772de7e0fc2a3e8c02c71b6a3c147620d044d"
RUNS = {
    "C_base_nospec": dict(commit=BASE, config="FA3+FP8KV+DP8 attn, no spec (reference)"),
    "BD_fix_spec": dict(commit=FIX, config="FA3+FP8KV+DP8 attn+EAGLE3 (problem config)"),
    "E_fix_nospec": dict(commit=FIX, config="FA3+FP8KV+DP8 attn, no spec"),
    "BD_fix_spec_repeat": dict(commit=FIX, config="FA3+FP8KV+DP8 attn+EAGLE3 (problem config), repeat run"),
    "E2_base_spec_nodp": dict(commit=BASE, config="FA3+FP8KV+EAGLE3, attention TP8 (no DP attn)"),
    "E2_fix_spec_nodp": dict(commit=FIX, config="FA3+FP8KV+EAGLE3, attention TP8 (no DP attn)"),
}
def load(run):
    d = sorted(glob.glob(f"{O}/predictions/{run}/sgl_eval_gsm8k_*"))[-1]
    rows = [json.loads(l) for l in open(f"{d}/output-rs0.jsonl")]
    return d, rows, json.load(open(f"{d}/metrics.json"))
metrics, per = {}, {}
for run, info in RUNS.items():
    d, rows, m = load(run)
    norm = []
    for r in rows:
        status = "ok"
        if r.get("finish_reason") == "error" or not r.get("generation"):
            status = "error_or_empty"
        elif r.get("finish_reason") == "length":
            status = "truncated"
        elif r.get("predicted_answer") in (None, ""):
            status = "parse_failed"
        norm.append(dict(sample_id=r["id"], expected_answer=r["expected_answer"],
            raw_output=r.get("generation"), extracted_answer=r.get("predicted_answer"),
            correct=bool(r.get("symbolic_correct")), finish_reason=r.get("finish_reason"),
            status=status, num_generated_tokens=r.get("num_generated_tokens")))
    norm.sort(key=lambda x: int(x["sample_id"].split("-")[1]))
    with open(f"{O}/predictions/{run}.jsonl", "w") as f:
        for x in norm: f.write(json.dumps(x, ensure_ascii=False) + "\n")
    per[run] = {x["sample_id"]: x for x in norm}
    n = len(norm); c = sum(x["correct"] for x in norm)
    cnt = lambda s: sum(x["status"] == s for x in norm)
    metrics[run] = dict(commit=info["commit"], config=info["config"], dataset="gsm8k test (1319, sgl-eval 0.1.3 vendored NeMo-Skills prompt, 0-shot chat)",
        total=n, correct=c, accuracy=round(c / n, 6), failed_or_empty=cnt("error_or_empty"),
        truncated=cnt("truncated"), parse_failed=cnt("parse_failed"),
        latency_seconds=round(m["latency_seconds"], 1), gen=m["gen"], num_threads=m["num_threads"],
        sgl_eval_run_dir=d)
def cmp(a, b):
    A, B = per[a], per[b]; assert A.keys() == B.keys()
    ab = sorted([k for k in A if A[k]["correct"] and not B[k]["correct"]], key=lambda s: int(s.split("-")[1]))
    ba = sorted([k for k in A if B[k]["correct"] and not A[k]["correct"]], key=lambda s: int(s.split("-")[1]))
    return dict(reference=a, compared=b, n=len(A),
        delta_pp=round((metrics[b]["correct"] - metrics[a]["correct"]) / len(A) * 100, 3),
        both_correct=sum(A[k]["correct"] and B[k]["correct"] for k in A),
        both_wrong=sum((not A[k]["correct"]) and (not B[k]["correct"]) for k in A),
        ref_correct_cmp_wrong=ab, ref_wrong_cmp_correct=ba,
        identical_text=sum(A[k]["raw_output"] == B[k]["raw_output"] for k in A))
comparisons = [cmp("C_base_nospec", "BD_fix_spec"), cmp("C_base_nospec", "E_fix_nospec"),
               cmp("E2_base_spec_nodp", "E2_fix_spec_nodp"), cmp("E_fix_nospec", "BD_fix_spec"), cmp("BD_fix_spec", "BD_fix_spec_repeat")]
json.dump(dict(runs=metrics, comparisons=comparisons), open(f"{O}/metrics.json", "w"), indent=2)
for k, v in metrics.items():
    print(f"{k:20s} {v['commit'][:10]} {v['correct']}/{v['total']} acc={v['accuracy']*100:.2f}% trunc={v['truncated']} fail={v['failed_or_empty']} parse_fail={v['parse_failed']} t={v['latency_seconds']}s")
for c in comparisons:
    print(f"{c['reference']} -> {c['compared']}: delta={c['delta_pp']:+.3f}pp  ref_ok/cmp_wrong={len(c['ref_correct_cmp_wrong'])} ref_wrong/cmp_ok={len(c['ref_wrong_cmp_correct'])} both_ok={c['both_correct']} both_wrong={c['both_wrong']} identical_text={c['identical_text']}")
